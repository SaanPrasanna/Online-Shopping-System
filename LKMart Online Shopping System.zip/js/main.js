
// Loader
$(document).ready(function(){

	$(".loader").fadeOut();
	$("#preloder").delay(400).fadeOut("fast");

	

});
